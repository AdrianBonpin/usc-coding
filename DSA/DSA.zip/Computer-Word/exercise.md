# Computer World Exercise
## 1. Finding the Bit Pattern of A Given Number
- Write the code of the function that will display the bit-pattern of a given integer
## 2. Given the data type definition of a set implemented using computer word char:
- typedef struct unsigned char SET
- Create the following operations: initSet, displaySet, insert, member, delete, union, intersection, difference